package br.com.aula.escola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
